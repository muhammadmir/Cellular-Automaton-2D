from .automaton import Automaton
